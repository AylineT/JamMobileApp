import { SizableText } from "tamagui";

export const ProfileTab = () => {
  return <SizableText>Profile Content</SizableText>
};
