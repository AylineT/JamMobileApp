import { SizableText } from "tamagui";

export const JamsTab = () => {
  return <SizableText>Jams Content</SizableText>
};
