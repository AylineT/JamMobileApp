import ChatScreen from '../screens/ChatScreen'

export default function ChatRoute() {
  return <ChatScreen />
}
